package com.TESSERA.Eq13Tessera.eventos.dto;

public class ZonaRequest {
    
}
